#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-mfs
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/mfs /data/adb/modules/fuse-mfs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/mfs /data/adb/modules/fuse-mfs/system/bin
    ;;
ln -s mfs /data/adb/modules/fuse-mfs/system/bin/mount.mfs
ui_print "Module has been installed!"
esac
