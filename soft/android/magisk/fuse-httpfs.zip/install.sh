#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-httpfs2/system/bin
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/httpfs2 /data/adb/modules/fuse-httpfs2/system/bin
    ;;
*)
    mv /data/local/tmp/system32/httpfs2 /data/adb/modules/fuse-httpfs2/system/bin
    ;;
esac
ln -s httpfs2 /data/adb/modules/fuse-httpfs2/system/bin/mount.httpfs2
ui_print "Installation completed!"
