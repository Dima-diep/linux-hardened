#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-mergerfs
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/mergerfs /data/adb/modules/fuse-mergerfs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/mergerfs /data/adb/modules/fuse-mergerfs/system/bin
    ;;
ln -s mergerfs /data/adb/modules/fuse-mergerfs/system/bin/mount.mergerfs
ui_print "Module has been installed!"
esac
