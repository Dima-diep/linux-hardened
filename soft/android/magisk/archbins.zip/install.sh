#!/system/bin/sh
ui_print "Unpacking archbins..."
mkdir -p /data/adb/modules/archbins/system/bin
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/* /data/adb/modules/archbins/system/bin
    ;;
*)
    mv /data/local/tmp/system32/* /data/adb/modules/archbins/system/bin
    ;;
esac
ui_print "Installation completed!"
