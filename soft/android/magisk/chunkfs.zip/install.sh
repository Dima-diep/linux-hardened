#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/chunkfs/system/bin
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/chunkfs /data/adb/modules/chunkfs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/chunkfs /data/adb/modules/chunkfs/system/bin
    ;;
esac
ln -s chunkfs /data/adb/modules/chunkfs/system/bin/mount.chunkfs
ui_print "Installation completed!"
