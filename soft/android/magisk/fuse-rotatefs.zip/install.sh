#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-rotatefs
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/rotatefs /data/adb/modules/fuse-rotatefs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/rotatefs /data/adb/modules/fuse-rotatefs/system/bin
    ;;
ln -s rotatefs /data/adb/modules/fuse-rotatefs/system/bin/mount.rotatefs
ui_print "Module has been installed!"
esac
