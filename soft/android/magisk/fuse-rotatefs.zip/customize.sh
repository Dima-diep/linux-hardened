MODPATH=/data/adb/modules/fuse-rotatefs
