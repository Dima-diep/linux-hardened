#!/system/bin/sh
mkdir -p /data/adb/modules/cpuboost
ui_print "Unpacking service..."
unzip -d/data/adb/service.d "$ZIPFILE" 0000cpuboost
chmod 0500 /data/adb/service.d/0000cpuboost
ui_print "Reboot your device!"
