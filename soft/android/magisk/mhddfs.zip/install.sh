#!/system/bin/sh
ui_print "Unpacking module..."
mkdir -p /data/adb/modules/mhddfs/system/bin
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/mhddfs /data/adb/modules/mhddfs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/mhddfs /data/adb/modules/mhddfs/system/bin
    ;;
esac
ln -s mhddfs /data/adb/modules/mhddfs/system/bin/mount.mhddfs
ui_print "Installation completed!"
