#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/exfatprogs
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/* /data/adb/modules/exfatprogs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/* /data/adb/modules/exfatprogs/system/bin
    ;;
esac
ui_print "Module has been installed!"
