#!/system/bin/sh
unzip "$ZIPFILE" -d/data/local/tmp
for i in /system/*bin /system/etc /system/lib* /vendor/*bin /vendor/etc /system/usr /vendor/lib*; do
    if [ -d "$i" ]; then
        ui_print "Mounting $i..."
        mkdir -p /data/adb/modules/magiskfs"$i"
        touch /data/adb/modules/magiskfs"$i"/magisk-mountpoint
        echo "magisk-data" > /data/adb/modules/magiskfs"$i"/magisk-mountpoint
    fi
done
ui_print "Restart your device for enable mount..."
