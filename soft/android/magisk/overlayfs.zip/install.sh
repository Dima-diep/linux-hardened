#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-overlayfs/system/bin
case $(uname -m) in
    *64)
        mv /data/local/tmp/system64/fuse-overlayfs /data/adb/modules/fuse-overlayfs/system/bin
        ;;
    *)
        mv /data/local/tmp/system32/fuse-overlayfs /data/adb/modules/fuse-overlayfs/system/bin
        ;;
esac
ln -s fuse-overlayfs /data/adb/modules/fuse-overlayfs/system/bin/mount.overlay
ln -s fuse-overlayfs /data/adb/modules/fuse-overlayfs/system/bin/overlay
