#!/system/bin/sh
mkdir -p /data/adb/modules/te2pe/system/bin
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
case $(uname -m) in
    *64)
        export BINFILE=/data/local/tmp/system64/te2pe
        ;;
    *)
        export BINFILE=/data/local/tmp/system32/te2pe
        ;;
esac
mv "$BINFILE" /data/adb/modules/te2pe/system/bin
ui_print "Module is installed."
