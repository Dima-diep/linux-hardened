MODPATH=/data/adb/modules/cpuboost
