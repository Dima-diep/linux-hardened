#!/system/bin/sh
ui_print "Unpacking module..."
mkdir -p /data/adb/modules/bindfs/system/bin
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/bindfs /data/adb/modules/bindfs/system/bin
    ;;
*)
    mv /data/local/tmp/system32/bindfs /data/adb/modules/bindfs/system/bin
    ;;
esac
ln -s bindfs /data/adb/modules/bindfs/system/bin/mount.bindfs
ui_print "Installation completed!"
