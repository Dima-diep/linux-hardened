#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/fuse-nfs/system/bin
mv /data/local/tmp/fuse-nfs /data/adb/modules/fuse-nfs/system/bin
ln -s fuse-nfs /data/adb/modules/fuse-nfs/system/bin/mount.nfs
ui_print "Installation completed!"
