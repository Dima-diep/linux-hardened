#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
case $(uname -m) in
*64)
    mkdir -p /data/adb/modules/unionfs/system/bin
    mv /data/local/tmp/system64/* /data/adb/modules/unionfs/system/bin
    ln -s unionfs /data/adb/modules/unionfs/system/bin/mount.unionfs
    ;;
*)
    ui_print "Unsupported arch:" $(uname -m)
    exit 1
    ;;
esac
ui_print "Installation completed!"
