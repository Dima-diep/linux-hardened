#!/system/bin/sh
ui_print "Unpacking module..."
unzip -d/data/local/tmp "$ZIPFILE"
ui_print "Installing module..."
mkdir -p /data/adb/modules/ntfs-3g/system/bin
case $(uname -m) in
*64)
    mv /data/local/tmp/system64/mount.ntfs /data/adb/modules/ntfs-3g/system/bin
    ;;
*)
    mv /data/local/tmp/system32/mount.ntfs /data/adb/modules/ntfs-3g/system/bin
    ;;
esac
ui_print "Installation completed!"
