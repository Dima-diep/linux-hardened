package a;

import com.topjohnwu.magisk.model.download.DownloadService;

public class j extends DownloadService {
    /* stub */
}
