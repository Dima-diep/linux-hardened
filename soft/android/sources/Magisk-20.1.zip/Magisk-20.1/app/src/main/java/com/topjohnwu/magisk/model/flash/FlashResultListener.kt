package com.topjohnwu.magisk.model.flash

interface FlashResultListener {

    fun onResult(isSuccess: Boolean)

}