package a;

import com.topjohnwu.magisk.model.receiver.GeneralReceiver;

public class h extends GeneralReceiver {
    /* stub */
}
