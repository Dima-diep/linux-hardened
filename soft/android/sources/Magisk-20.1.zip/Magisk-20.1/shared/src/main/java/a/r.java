package a;

import com.topjohnwu.magisk.ProcessPhoenix;

public class r extends ProcessPhoenix {
}
