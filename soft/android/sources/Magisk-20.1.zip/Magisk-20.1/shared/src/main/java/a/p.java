package a;

import com.topjohnwu.magisk.FileProvider;

public class p extends FileProvider {
    /* Stub */
}
