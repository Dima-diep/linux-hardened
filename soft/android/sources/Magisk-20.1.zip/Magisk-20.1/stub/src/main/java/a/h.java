package a;

import com.topjohnwu.magisk.dummy.DummyReceiver;

public class h extends DummyReceiver {
}
