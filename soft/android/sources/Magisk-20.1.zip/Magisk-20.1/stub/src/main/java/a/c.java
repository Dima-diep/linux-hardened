package a;

import com.topjohnwu.magisk.DownloadActivity;

public class c extends DownloadActivity {
}
