package a;

import com.topjohnwu.magisk.components.DownloadModuleService;

public class j extends DownloadModuleService {
    /* stub */
}
