# v7.0.0
- Major UI redesign!
- Render Markdown natively (no more buggy WebView!)
- Support down to Android 4.1 (native Magisk only support Android 4.2 though)
- Significantly improve Magisk log disply performance
- Fix post OTA scripts for A/B devices
- Reduce memory usages when verifying and signing boot image
- Drop support for Magisk lower than v18.0
