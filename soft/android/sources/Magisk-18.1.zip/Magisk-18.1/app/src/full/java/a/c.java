package a;

import com.topjohnwu.magisk.SplashActivity;

public class c extends SplashActivity {
    /* stub */
}
