package a;

import com.topjohnwu.magisk.components.GeneralReceiver;

public class h extends GeneralReceiver {
    /* stub */
}
