package a;

import android.content.Context;

import com.topjohnwu.magisk.model.update.UpdateCheckService;

import androidx.annotation.NonNull;
import androidx.work.WorkerParameters;

public class g extends w<UpdateCheckService> {
    /* Stub */
    public g(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }
}
