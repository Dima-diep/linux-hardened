package a;

import com.topjohnwu.magisk.App;

public class e extends App {
    public e() {
        super();
    }

    public e(Object o) {
        super(o);
    }
}
