package a;

import com.topjohnwu.magisk.DelegateComponentFactory;

public class a extends DelegateComponentFactory {
}
