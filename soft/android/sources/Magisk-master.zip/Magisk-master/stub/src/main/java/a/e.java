package a;

import com.topjohnwu.magisk.DelegateApplication;

public class e extends DelegateApplication {
}
